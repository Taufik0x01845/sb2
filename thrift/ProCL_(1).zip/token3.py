from Classclient import LineBot
import json,threading,subprocess
def login(resp, auth):
	bot = LineBot(resp, auth)

Znf = threading.Thread(target=login, args=('A1','u94b77722942fc947033dbd1cef34b1a7:aWF0OiAxNTQ3OTY1MzQwNTIyCg==..5HCG7N/NAmHjaS8+h/2UtpRhXkM=')).start()
Znf = threading.Thread(target=login, args=('A2','u4ad95e12f4df1214d777896d940619d4:aWF0OiAxNTQ4MDA4NjUyMTcwCg==..ViCnR047D5D2oasYRH0hDmzRtXc=')).start()
Znf = threading.Thread(target=login, args=('A3','u932df212d6cc5939167961231692d529:aWF0OiAxNTQ4MTQxMjEwOTY0Cg==..UDR/AWTdOBS6ibCsQ5Tx5bE6YQA=')).start()
Znf = threading.Thread(target=login, args=('A4','uc714691ddc8395749d319847b1b9ced0:aWF0OiAxNTUwMTI3ODU2NTU0Cg==..d3zbLyrJfN8pAepaS7ZrIj83qsI=')).start()
Znf = threading.Thread(target=login, args=('A5','ua5bf778c386852ff46093b89cda9b546:aWF0OiAxNTUwMTI4OTk1MTM1Cg==..1pyJui8ETKWsX2H3esRR++xyPG4=')).start()
#Znf = threading.Thread(target=login, args=('Z6','EBfd7xGnR9LR9Q9HBh2a.1S6SJj1xrKfnVW0KDxVOsG.gIBsR6G2oxaQc108OM+cmpFjJK79JftsBjSGH6Vwj3M=')).start()
#Znf = threading.Thread(target=login, args=('Z7','EBkW36kNdQsbNutIRVR4.mHC07lXmDJB/26BbyA/jba.+TiaZ6JjO9MH/Dsm6jlIRy2zsMWZfUnJjfuUeXgC8ik=')).start()
#Znf = threading.Thread(target=login, args=('Z8','Ey4mAvxXDzGUmQm2paCd.SGNSKinMEE2bZsimbLTb7q.LGmyNecWQi/ZiGyYoOAH2oWZznzPpxVfHbvIqbYjMpM=')).start()
#Znf = threading.Thread(target=login, args=('Z9','Ey1CCMluRdubCK5YB6xc.C5/g1Ftwh9sHt1XRFxidFa.06GaqEU2dP/xlI7k1c6d1gO2+blD0rMTeewKFyJWM7w=')).start()
#Znf = threading.Thread(target=login, args=('Z10','EyVYF854Nw143KNze4T9.hjX5lMxewhd87xpCSit0sq.yU0FJQjsB277imQWARn2t5OusYQ/rIyomHrM6IWF3XQ=')).start()
#Znf = threading.Thread(target=login, args=('Z11','EvG2DkK6QLYfkrOE34mb.Q1bAQ+xHusJvIkMSiHWiMW.SveN6QxuDgRfdCyvTuhraDHHAj6nm5yDAfoiAtVaax8=')).start()
#Znf = threading.Thread(target=login, args=('Z12','EvExw0Vn0dJPw4XKsEx0.WbVZ1Ar5szXGYCdURkmaCa.tXEyFtNrc4/3P+ohdjzAWrMIJgvX37Sf9drY8BceI9k=')).start()
#Znf = threading.Thread(target=login, args=('Z3',4'Evx9F3Q1vw18XN2gkd12.MyJEBI/sMjpdlP4eAGqAqG.7BO+s278L1BmX+0g8vtYjCinCXRcCLKei5XPy2sP0qo=')).start()
#Znf = threading.Thread(target=login, args=('Z14','EvSD0JI3wsRJIBpTroD3.lvgoXiMV6lYaxJpXCqg4OW.ObX/r19C+ROH9Ndkewl3Ta0bmOrj0YjfKrmE5mI+IjE=')).start()
#Znf = threading.Thread(target=login, args=('Z15','EvOEFjQMh4oXUGGLJdn2.pbB/Ok82nrF+nWHt1NRwiG.pyI/2IgQ6NbGqpetwUJjzo/knrGAgm0AAEpLznicaXU=')).start()
#Znf = threading.Thread(target=login, args=('Z16','EvGnm6NKrC1iM3zfNiL8.VjxLWhxuKfLXdeFYRjOv6a.kYAj7E4OLQKZypagfvd/qdjDC3N66A65jGX4CN/5GHw=')).start()
#Znf = threading.Thread(target=login, args=('Z17','EvjYpoYHVnTF7UU9f7Ie.4Z4+vOwSG3HXMipggoRo7G.ON0muiHwOtzri+FMyqmXNbikXJkfXuKY9o04VZOI7Ng=')).start()
#Znf = threading.Thread(target=login, args=('Z8','EvOkOpbioVVYLWE8VAY9.yM2k4XRQK8D8kzXmEhQN2q.o93qFjUS+DgtWUUE7hKvRUfQxmmRVO3xNJjN53mxhxY=')).start()




print('Login Berhasil!')
